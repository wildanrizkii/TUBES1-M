package com.example.tubes;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.tubes.databinding.FragmentPertemuanBinding;

public class PertemuanFragment extends Fragment {
    public PertemuanFragment(){}
    FragmentPertemuanBinding binding;

    public static PertemuanFragment newInstance(String title) {
        Bundle args = new Bundle();
        PertemuanFragment pertemuanFragment = new PertemuanFragment();
        args.putString("title", title);
        pertemuanFragment.setArguments(args);
        return pertemuanFragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentPertemuanBinding.inflate(inflater);
        binding.btnPertemuan.setOnClickListener(this::onClicked);
        return binding.getRoot();
    }

    private void onClicked(View view) {
        Bundle result = new Bundle();
        Bundle send = new Bundle();
        result.putInt("page", 2);
        Log.d("debug", "ClickMe Clickeddd!");
        getParentFragmentManager().setFragmentResult("changePage", result);
        getParentFragmentManager().setFragmentResult("send", send);
    }

}
